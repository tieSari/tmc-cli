from setuptools import setup

setup (
    scripts = [
        'scripts/tmc.py'
    ]
)
