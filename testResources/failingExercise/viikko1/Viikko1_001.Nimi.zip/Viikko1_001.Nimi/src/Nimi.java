public class Nimi {
    
    public static void main(String[] args) {
        // Kirjoita ohjelmasi tähän alle
      
        // Mikäli et vielä ole vastannut vielä kyselyyn, tee se HETI
        // osoitteessa: http://laatu.jamo.fi/ 

    }

}