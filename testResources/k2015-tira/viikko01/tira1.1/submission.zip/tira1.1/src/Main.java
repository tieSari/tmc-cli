import java.util.*;

public class Main {
    public static boolean kaksiSamaa(String mjono) {
        return false;
    }

    public static void main(String[] args) {
        System.out.println(kaksiSamaa("ABAABA"));
        System.out.println(kaksiSamaa("XXXXX"));
        System.out.println(kaksiSamaa("ABCABC"));
        System.out.println(kaksiSamaa("ABABA"));
    }

}

