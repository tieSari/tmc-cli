public class HeiMaailma {

    public static void main(String[] args) {
        // Toteuta ohjelmasi tähän.
	System.out.println("Hei maailma!");
    }

}
