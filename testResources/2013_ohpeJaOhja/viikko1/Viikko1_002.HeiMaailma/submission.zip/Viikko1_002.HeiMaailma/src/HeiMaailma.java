public class HeiMaailma {

    public static void main(String[] args) {
        // Toteuta ohjelmasi tähän.

    }

}